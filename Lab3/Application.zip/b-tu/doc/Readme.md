# btu - A University Student Management System

Basic management System for Students.

## Folder Structure

This program will be delivered containing the following folders and files:

* bin - binary files created by compilation
* doc - Contains this documentation
* include - C++ Header Files and Prototype decleration
* lib - External Libraries used by this program
* src - Source Code, i.e. C++ Source code files
* test - Test data, i.e. a database containing B-TU Student data


### Scheduling

Add further Sheduling here


## Authors

* **Torsten Ziemann** - [contact](mailto:torsten.ziemann@b-tu.de)

See also the list of [staff members](https://www.b-tu.de/en/fg-it-sicherheit/team/staff) who related to this project.
