#ifndef __BTU_H__
#define __BTU_H__

/**
 * Options allowed for the cli
 */
#define OPTION_ADD "add"
#define OPTION_REMOVE "remove"
#define OPTION_STATISTICS "print"

#endif
